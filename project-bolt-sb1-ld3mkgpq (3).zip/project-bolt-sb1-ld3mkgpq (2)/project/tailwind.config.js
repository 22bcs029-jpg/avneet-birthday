/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'cream': {
          50: '#fffef9',
          100: '#fffcf0',
          200: '#fff8e1',
          300: '#fff4d1',
        },
      },
    },
  },
  plugins: [],
};
