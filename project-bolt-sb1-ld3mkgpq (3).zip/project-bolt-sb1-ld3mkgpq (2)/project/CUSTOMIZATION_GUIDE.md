# Birthday Website Customization Guide

This beautiful birthday website for Avneet is ready to use! Here's how to customize it:

## Password
The current password is: `avneet0401`
To change it, edit `src/components/PasswordEntry.tsx` line 17.

## Adding Photos to the Gallery
Replace the placeholder Pexels images in `src/components/BirthdayWebsite.tsx` around line 192-201 with your own photos:
1. Upload your photos to a hosting service (Imgur, Google Drive with public links, etc.)
2. Replace the URLs in the image array

## Adding a Video
In `src/components/BirthdayWebsite.tsx` around line 211:
1. Replace the empty `src=""` with your video URL
2. You can use YouTube embeds, Google Drive videos, or self-hosted videos

## Customizing the Love Letter
Edit the `loveLetterText` variable in `src/components/BirthdayWebsite.tsx` starting around line 83 to personalize your message.

## Background Music
The current music URL is from Bensound (royalty-free). To add your own:
1. Upload your music file or get a direct link to an MP3
2. Replace the URL in `src/components/BirthdayWebsite.tsx` around line 87

## Color Scheme
The pastel colors are defined in:
- `tailwind.config.js` for cream tones
- CSS uses pink, purple, and cream throughout
- You can adjust these in `src/index.css` and component files

## Features Included
- Password protection
- Countdown timer to January 4th
- Animated hero section
- About section
- Photo gallery with smooth animations
- Video wishes section
- Love letter with typewriter effect
- Background music control
- Floating hearts and sparkles
- Smooth scroll animations
- Fully responsive design

Enjoy surprising Avneet with this beautiful website!
